import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import com.student.manage.Student;
import com.student.manage.Studentdao;

public class Start {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
			System.out.print("Welcome to the logistics warehouse \n");
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			while(true)
			{

				System.out.println("Press 1 to put the product into the warehouse");
				System.out.println("Press 2 to remove the product from the warehouse");
				System.out.println("Press 3 to view the current product of the warehouse");
				System.out.println("Press 4 to come out of  the warehouse");
				int c=Integer.parseInt(br.readLine());
				
				if (c==1)
				{
					System.out.println("Enter the Product name");
					String Pname=br.readLine();
					System.out.println("Enter the Price of the Product");
					int Price =Integer.parseInt(br.readLine());
					System.out.println("Enter the amount of the Product");
					int A =Integer.parseInt(br.readLine());
					System.out.println("Enter the Family of the Product");
					String F=br.readLine();
					
				
					Student st = new Student(Pname,Price,A,F);
					boolean answer=Studentdao.insertStudentToDB(st);
					if(answer) {
						System.out.println("Successfully Added");
					}
					else {
						System.out.println("Something wrong");}
					}

					
				
			else if (c == 2)
			{System.out.println("Enter Product id to delete:");
			int pid=Integer.parseInt(br.readLine());
			boolean f=Studentdao.deleteStudent(pid);
			if(f) {System.out.println("Successfully removed:");
				
			}else {System.out.println("Something went wrong");
			}
			

	}else if(c==3) {
		Studentdao.showAll();
	}
	else if(c==4) {
		System.out.println("Thank you for choosing our warehose");
		break;
		
	}

			}}}
