package com.student.manage;

public class Student {
	
	private int Id;
	private String PName;
	private int Price;
	private int Amount;
	private String Family;
	public Student(int id, String pName, int price, int amount, String family) {
		super();
		Id = id;
		PName = pName;
		Price = price;
		Amount = amount;
		Family = family;
	}
	public Student(String pName, int price, int amount, String family) {
		super();
		PName = pName;
		Price = price;
		Amount = amount;
		Family = family;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getPName() {
		return PName;
	}
	public void setPName(String pName) {
		PName = pName;
	}
	public int getPrice() {
		return Price;
	}
	public void setPrice(int price) {
		Price = price;
	}
	public int getAmount() {
		return Amount;
	}
	public void setAmount(int amount) {
		Amount = amount;
	}
	public String getFamily() {
		return Family;
	}
	public void setFamily(String family) {
		Family = family;
	}
	public String toString() {
		return "Student [Id=" + Id + ", PName=" + PName + ", Price=" + Price + ", Amount=" + Amount + ", Family="
				+ Family + "]";
	}
	
	
}