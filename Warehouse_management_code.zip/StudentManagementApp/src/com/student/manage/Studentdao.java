package com.student.manage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class Studentdao {
	
	public static  boolean insertStudentToDB(Student st)
	{
  
		boolean f=false;
		
		try {	
	Connection con=CP.createC();
	String q ="insert into product(name,price,amount,family) values(?,?,?,?)";
	PreparedStatement pstmt=con.prepareStatement(q);
	pstmt.setString(1,st.getPName());
	pstmt.setLong(2,st.getPrice());
	pstmt.setLong(3,st.getAmount());
	pstmt.setString(4,st.getFamily());
	
	
	pstmt.executeUpdate();
	f=true;
}

catch(Exception e) {
	e.printStackTrace();
	
} return f;
	}

	public static boolean deleteStudent(int pid) {

		
	  
			boolean f=false;
			
			try {	
		Connection con=CP.createC();
		String q ="delete from  product where pid=? ";
		PreparedStatement pstmt=con.prepareStatement(q);
		pstmt.setInt(1,pid);
		
		pstmt.executeUpdate();
		f=true;
	}

	catch(Exception e) {
		e.printStackTrace();
		
	} return f;
		}
		// TODO Auto-generated method stub

	public static boolean showAll() {
		// TODO Auto-generated method stub

		boolean f=false;
		
		try {	
	Connection con=CP.createC();
	String q ="select * from product";
	Statement stmt=con.createStatement();
	ResultSet set=stmt.executeQuery(q);
	
	
	while(set.next()){
		
		int pid=set.getInt(1);
		String name=set.getString(2);
		int price=set.getInt(3);
		int amount=set.getInt(4);
		String family=set.getString(5);
	System.out.println("ID:"+ pid);
	System.out.println("NAME:"+ name);
	System.out.println("PRICE"+ price);
	System.out.println("Number of Products"+ amount);
	System.out.println("family"+ family);
	System.out.println("=============================");
	}
	
	
		
	
	f=true;
}

catch(Exception e) {
	e.printStackTrace();
	
} return f;
	}
		
	}
		

      

