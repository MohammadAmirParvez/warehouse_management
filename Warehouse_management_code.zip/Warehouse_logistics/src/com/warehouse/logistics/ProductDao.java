package com.warehouse.logistics;

import java.sql.Connection;
import java.sql.PreparedStatement;

public  class ProductDao {
	public static boolean insertProductToDB(Product P) {
		boolean f=false;
	
		try {
		Connection con=CP.createC();
		String q="insert into product( name, price, amount) values( ?, ?, ?)";
		PreparedStatement pstmt=con.prepareStatement(q);
		pstmt.setString(1, P.getName());
		
		pstmt.setInt(2, P.getPrice());
		pstmt.setInt(3, P.getAmount());
		
		
		pstmt.executeUpdate();
		f=true;
	
	}
		catch(Exception e) {
			e.printStackTrace();
			
			
		}
		return f;
}
}