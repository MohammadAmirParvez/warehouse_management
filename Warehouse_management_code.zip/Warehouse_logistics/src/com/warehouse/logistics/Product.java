package com.warehouse.logistics;

public class Product {
	private int ProductId;
	private String name;
	private int price;
	private int amount;
	public Product(int productId, String name, int price, int amount) {
		super();
		ProductId = productId;
		this.name = name;
		this.price = price;
		this.amount = amount;
	}
	public Product(String name, int price, int amount) {
		super();
		this.name = name;
		this.price = price;
		this.amount = amount;
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getProductId() {
		return ProductId;
	}
	public void setProductId(int productId) {
		ProductId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String toString() {
		return "Product [ProductId=" + ProductId + ", name=" + name + ", price=" + price + ", amount=" + amount + "]";
	}
	


}
