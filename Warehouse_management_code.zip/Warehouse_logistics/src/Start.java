import java.io.*;
import com.warehouse.logistics.Product;
import com.warehouse.logistics.ProductDao;

public class Start {

	public static void main(String[] args) throws IOException{
		System.out.print("Welcome to the logistics warehouse ");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		while(true)
		{
			System.out.println("Press 1 to in the product into the warehouse");
			System.out.println("Press 2 to out the product from the warehouse");
			System.out.println("Press 3 to view the current product of the warehouse");
			System.out.println("Press 4 to come out of  the warehouse");
			int c=Integer.parseInt(br.readLine());
			
			if (c==1)
			{
				System.out.println("Enter product name");
				String name=br.readLine();
				
				System.out.println("Enter  the price of the product");
				int price =Integer.parseInt(br.readLine());
				System.out.println("Enter  the  number of the product");
				int amount =Integer.parseInt(br.readLine());
				
				
				Product P =new Product(name,price,amount);
				
				
				boolean a=ProductDao.insertProductToDB(P);
				
				System.out.print(P);
				
				if(a)
				{
					System.out.println("Product successfully added to the product list");
					
				}
				else {
					System.out.println("Something went wrong try again");
				}
				}
				
		}
				
		
		// TODO Auto-generated method stub

	}

}