import java.sql.Connection;

public class connection {
	
	
	static Connection connection= null;
	static String databasename="";
	static String url="jdn:mysql://localhost:3306/" + databasename;
	
	static String username="root";
	static String  password="9336140924";
	
	public static void main (string [] args) throws InstantiationException,IllegalAccessException,ClassNotFoundException{
		class.forname("com.mysql.jdbc.Driver").newInstance();
		connection=DriverManager.getConnection(url,username,password);
		PreparedStatement ps = connection.prepareStatement("INSERT INTO 'mydb' ('building') VALUES ('A1');");
		int status = ps.executeUpdate();
		if status (!=0) {
			System.out.println("CREATED");
			Systemout.println("inserted");
		}
		
	}
	}
